package com.proyecto.proyecto.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.proyecto.proyecto.model.Pedido;

public interface PedidoRepository extends JpaRepository<Pedido,Long>{

    
} 