package com.proyecto.proyecto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoApplicationTests {

	@Test
	void contextLoads() {
	}

}
